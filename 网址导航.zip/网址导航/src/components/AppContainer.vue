<script setup lang="ts">

</script>

<template>
  <div lg="w-1240" mx-auto w-92p class="mobile-container">
    <slot />
  </div>
</template>
