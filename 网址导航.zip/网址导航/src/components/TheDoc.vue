<script setup>

</script>

<template>
  <div p-md>
    <div class="mobile-doc" mt-xs>
      <div>
        <slot />
      </div>
    </div>
  </div>
</template>
