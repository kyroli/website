<script setup lang="ts">
defineOptions({
  name: 'TheFooter',
})
</script>

<template>
  <div mt-44 flex-center gap-x-8>

  </div>
</template>
