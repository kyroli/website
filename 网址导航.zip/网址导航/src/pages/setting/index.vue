<script setup lang="ts">
import HomePage from '@/pages/home/index.vue'

defineOptions({
  name: 'SettingPage',
})
</script>

<template>
  <HomePage />
</template>

<style lang="scss" scoped>

</style>
